package com.example.tareanetjson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.tareanetjson.javabean.Currently;
import com.example.tareanetjson.javabean.Resultados;
import com.example.tareanetjson.retrofitUtils.ApiTemperaturas;
import com.example.tareanetjson.retrofitUtils.RetrofitClient;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class WeatherActivity extends AppCompatActivity {
    String longitud;
    String latitud;
    TextView tvLocalizacion;
    ImageView ivIconoPpal;
    TextView tvHora;
    TextView tvTemperatura;
    TextView tvSensacionT;
    TextView tvValHumedad;
    TextView tvValPrecipitacion;
    TextView tvSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        getSupportActionBar().hide();
        latitud = getIntent().getStringExtra("lati");
        longitud = getIntent().getStringExtra("longi");

        tvLocalizacion = findViewById(R.id.tvLocaliz);
        ivIconoPpal = findViewById(R.id.ivIconoPpal);
        tvHora = findViewById(R.id.tvHora);
        tvTemperatura = findViewById(R.id.tvTemperatura);
        tvSensacionT = findViewById(R.id.tvSensacTermica);
        tvValHumedad = findViewById(R.id.tvValorHumedad);
        tvValPrecipitacion = findViewById(R.id.tvValorPrecip);
        tvSummary = findViewById(R.id.tvSummary);
        consumirWS();
    }

    public void consumirWS(){
        Retrofit r = RetrofitClient.getClient(ApiTemperaturas.BASE_URL);
        ApiTemperaturas ars = r.create(ApiTemperaturas.class);
        Call<Resultados> call = ars.obtenerResultados(ApiTemperaturas.KEY, latitud, longitud, ApiTemperaturas.EXCLUDE,
                ApiTemperaturas.LANG);
        call.enqueue(new Callback<Resultados>() {
            @Override
            public void onResponse(Call<Resultados> call, Response<Resultados> response) {
                if (!response.isSuccessful()) {
                    Log.i("Error", "Error onResponse" + response.code());
                } else {
                    Resultados r = (Resultados) response.body(); //Si ha funcionado guardamos los resultados en r
                    //Obtenemos todos los datos uno a uno
                    double temperatura = r.getCurrently().getTemperature();
                    int temp = (int)Math.round((temperatura-32)/1.8); //Convertimos los Fahrenheit a grados
                    double sensacionTermica = r.getCurrently().getApparentTemperature();
                    int tempeFeel = (int)Math.round((sensacionTermica -32)/1.8); //Convertimos los Fahrenheit a grados
                    Log.d("tem", "Sensacion termica: " + tempeFeel);

                    String sumario = r.getCurrently().getSummary();
                    String localizacion = r.getTimezone();

                    //Obtenemos la hora mediate la clase Date, el objeto está en milisegundos por eso lo multiplicamos por 1000
                    //Date dateTime = new Date(r.getCurrently().getTime()*1000); Como da una hora incorrecta calculamos la de la zona
                    String sDate = mostrarHora(localizacion);
                    double humedad = r.getCurrently().getHumidity();
                    double lluvia = r.getCurrently().getPrecipProbability();
                    Drawable drawable = mostrarIconosTiempo(r); //Método para obtener el icono que hay que mostrar según la info
                    //Currently t = r.getCurrently();
                    tvLocalizacion.setText(localizacion);
                    ivIconoPpal.setImageDrawable(drawable); //Cuidado con hacer un serImageResource con el entero q se desborda
                    tvHora.setText(sDate);
                    tvTemperatura.setText(String.valueOf(temp));
                    tvSensacionT.setText(String.format(getString(R.string.tv_sensacion), tempeFeel));
                    tvValHumedad.setText(humedad + " %");
                    tvValPrecipitacion.setText(lluvia + " %");
                    tvSummary.setText(sumario);
                }
            }

            @Override
            public void onFailure(Call<Resultados> call, Throwable t) {
                Log.i("Error", "Error onFailure" + t.getMessage());//Mostramos el mensaje si peta
            }
        });
    }

    private Drawable mostrarIconosTiempo(Resultados res) {
        int refIcono = 0; //Asociamos el icono según la info qu toque, retornamos la referencia del entero q equivale al icono

        if (res.getCurrently().getIcon().equals("clear-day")) {
            refIcono = R.drawable.clear_day;

        } else if (res.getCurrently().getIcon().equals("clear-night")) {
            refIcono = R.drawable.clear_night;

        }  else if (res.getCurrently().getIcon().equals("rain")) {
            refIcono = R.drawable.rain;

        }  else if (res.getCurrently().getIcon().equals("snow")) {
            refIcono = R.drawable.snow;

        } else if (res.getCurrently().getIcon().equals("sleet")) {
            refIcono = R.drawable.sleet;

        } else if (res.getCurrently().getIcon().equals("wind")) {
            refIcono = R.drawable.wind;

        } else if (res.getCurrently().getIcon().equals("fog")) {
            refIcono = R.drawable.fog;

        } else if (res.getCurrently().getIcon().equals("cloudy")) {
            refIcono = R.drawable.cloudy;

        } else if (res.getCurrently().getIcon().equals("partly-cloudy-day")) {
            refIcono = R.drawable.partly_cloudy;

        } else if (res.getCurrently().getIcon().equals("partly-cloudy-night")) {
            refIcono = R.drawable.cloudy_night;
        }
        return getResources().getDrawable(refIcono);
    }

    private String mostrarHora(String localizacion){
        //formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        //Almacenamos en un String la hora generada con el format creado
        //String timeString = formatter.format(dateTime);

        Date date = new Date(); //Obtenemos hora actual
        // Seleccionaremos el formato que queremos
        SimpleDateFormat formatter = new SimpleDateFormat("h:mm a");
        //Asignamos la zona horaria según localización
        TimeZone timeZone = TimeZone.getTimeZone(localizacion);
        formatter.setTimeZone(timeZone);
        //Almacenamos en un String la hora generada con el format creado
        String horaDef = formatter.format(date);

        return horaDef;
    }

    public void datosAdicionales(View view) {
        Intent i = new Intent(this, ActivityAmpliacion.class);
        i.putExtra("lati", latitud);
        i.putExtra("longi",longitud);
        startActivity(i);
    }

    public void salir(View view) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }
}
