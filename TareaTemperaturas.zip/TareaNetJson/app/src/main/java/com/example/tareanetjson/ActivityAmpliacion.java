package com.example.tareanetjson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.tareanetjson.javabean.Resultados;
import com.example.tareanetjson.retrofitUtils.ApiTemperaturas;
import com.example.tareanetjson.retrofitUtils.RetrofitClient;

import java.text.DecimalFormat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ActivityAmpliacion extends AppCompatActivity {
    String latitud;
    String longitud;
    TextView tvUv;
    TextView tvVisibil;
    TextView tvOzone;
    TextView tvIntensPrecip;
    TextView tvNubosidad;
    TextView tvViento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ampliacion);
        getSupportActionBar().hide();
        latitud = getIntent().getStringExtra("lati");
        longitud = getIntent().getStringExtra("longi");
        tvUv = findViewById(R.id.tvUV);
        tvVisibil = findViewById(R.id.tvVisibilidad);
        tvOzone = findViewById(R.id.tvOzono);
        tvIntensPrecip = findViewById(R.id.tvPrecipIntensidad);
        tvNubosidad = findViewById(R.id.tvNubes);
        tvViento = findViewById(R.id.tvViento);

        consumirWS();
    }

    private void consumirWS() {
        Retrofit r = RetrofitClient.getClient(ApiTemperaturas.BASE_URL);
        ApiTemperaturas ars = r.create(ApiTemperaturas.class);
        Call<Resultados> call = ars.obtenerResultados(ApiTemperaturas.KEY, latitud, longitud, ApiTemperaturas.EXCLUDE,
                ApiTemperaturas.LANG);
        call.enqueue(new Callback<Resultados>() {
            @Override
            public void onResponse(Call<Resultados> call, Response<Resultados> response) {
                if (!response.isSuccessful()) {
                    Log.i("Error", "Error onResponse" + response.code());
                } else {
                    Resultados r = (Resultados) response.body(); //Si ha funcionado guardamos los resultados en r
                    //Obtenemos todos los datos uno a uno
                    double indiceUV = r.getCurrently().getUvIndex();
                    double intensidadPrecip = r.getCurrently().getPrecipIntensity();
                    double velocidadViento = r.getCurrently().getWindSpeed();
                    double nubosidad = r.getCurrently().getCloudCover();
                    double nivelesOzono = r.getCurrently().getOzone();
                    double visibilidad = r.getCurrently().getVisibility();

                    DecimalFormat df = new DecimalFormat("0.00"); //Recortamos a 2 decimales

                    tvUv.setText(String.format(getString(R.string.tv_uv), df.format(indiceUV)));
                    tvVisibil.setText(String.format(getString(R.string.tv_visibilidad), df.format(visibilidad)));
                    tvOzone.setText(String.format(getString(R.string.tv_ozono), df.format(nivelesOzono)));
                    tvIntensPrecip.setText(String.format(getString(R.string.tv_intensidad_precipit), df.format(intensidadPrecip))+"%");
                    tvNubosidad.setText(String.format(getString(R.string.tv_nubes), df.format(nubosidad)));
                    tvViento.setText(String.format(getString(R.string.tv_viento), df.format(velocidadViento)));                }
            }

            @Override
            public void onFailure(Call<Resultados> call, Throwable t) {
                Log.i("Error", "Error onFailure" + t.getMessage());//Mostramos el mensaje si peta
            }
        });
    }

    public void salir(View view) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }
}
