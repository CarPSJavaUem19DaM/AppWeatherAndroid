package com.example.tareanetjson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etLati;
    EditText etLongi;
    //Pongo de ejemplo 40.430677, -3.612317

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etLati = findViewById(R.id.etLatitud);
        etLongi = findViewById(R.id.etLongitud);
    }

    public void consultarTiempo(View view) {
        String lati = etLati.getText().toString();
        String longi = etLongi.getText().toString();
        if (!lati.isEmpty() & !longi.isEmpty()){
            Intent i = new Intent(this, WeatherActivity.class);
            i.putExtra("lati", lati);
            i.putExtra("longi",longi);
            startActivity(i);
        } else {
            Toast.makeText(this, getString(R.string.toast_vacio), Toast.LENGTH_SHORT).show();
        }
    }

    public void consultarUbiGuardada(View view) {
        String lati = "40.431653";
        String longi = "-3.612522";
        Intent i = new Intent(this, WeatherActivity.class);
        i.putExtra("lati", lati);
        i.putExtra("longi",longi);
        startActivity(i);
    }
}
