package com.example.tareanetjson.retrofitUtils;

import com.example.tareanetjson.javabean.Resultados;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiTemperaturas {
    public static final String KEY= "11ce4328111023379e0fdc9d28c24a02";
    public static final String EXCLUDE = "minutely,hourly,daily,alerts,flags"; //flags&lang
    public static final String LANG = "es";
    public static final String BASE_URL = "https://api.darksky.net/";//La url completa es https://api.darksky.net/forecast/11ce4328111023379e0fdc9d28c24a02/40.5,-3.7?exclude=minutely,hourly,daily,alerts,flags&lang=es
    @GET("forecast/{key}/{latitude},{longitude}")
    Call<Resultados> obtenerResultados(@Path ("key") String key, @Path ("latitude") String latitude,
                                        @Path ("longitude") String longitude, @Query("exclude") String exclude,
                                        @Query("lang") String lang);
}
